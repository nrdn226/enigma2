#!/bin/sh
wget http://remyteam.xp3.biz/remy-rudream-crackbackup_V1.1_all.ipk -qO /tmp/remy-rudream-crackbackup_V1.1_all.ipk
echo ""
echo "    ***  REMY FULL BACKUP YUKLENIYOR ***"
echo ""
echo "    ***  DESTEK ICIN IRTIBATA GECINIZ ***"
echo ""
echo "    ***  UYDU ALICINIZI YENIDEN BASLATILIYOR ***"
echo ""
opkg --force-overwrite install /tmp/remy-rudream-crackbackup_V1.1_all.ipk
opkg install --force-reinstall --force-depends /tmp/remy-rudream-crackbackup_V1.1_all.ipk
rm -rf /tmp/remy-rudream-crackbackup_V1.1_all.ipk > /dev/null
opkg --force-overwrite install /tmp/*.ipk
opkg install --force-reinstall /tmp/*.ipk
opkg update && opkg install --force-reinstall --force-depends /tmp/*.ipk
killall -9 enigma2
sleep 1
exit 0