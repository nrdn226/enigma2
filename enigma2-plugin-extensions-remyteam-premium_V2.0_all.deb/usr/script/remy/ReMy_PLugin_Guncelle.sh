#!/bin/sh
wget http://remyteam.xp3.biz/enigma2-plugin-extensions-remyteam-premium_V2.0_all.ipk -qO /tmp/enigma2-plugin-extensions-remyteam-premium_V2.0_all.ipk
echo ""
echo "    ***  REMY_TEAM PLUGINI INDIRILIYOR ***"
echo ""
echo "    ***  DESTEK ICIN arslan_plaza@outlook.com IRTIBATA GECINIZ ***"
echo ""
sleep 2
rm -rf /usr/script/remy > /dev/null
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/RemyTeam > /dev/null
echo 'DELETED FILES FROM script FOLDER'
opkg --force-overwrite install /tmp/enigma2-plugin-extensions-remyteam-premium_V2.0_all.ipk
opkg install --force-reinstall /tmp/*.ipk
opkg update && opkg install --force-reinstall /tmp/enigma2-plugin-extensions-remyteam-premium_V2.0_all.ipk
sleep 1
echo 'DESTEK ICIN arslan_plaza@outlook.com'
echo  '***  REMY_TEAM V2.0 ***'
killall -9 enigma2
exit 0