#!/bin/sh
echo '#############################################'
echo '#   ReMy TeaM IpTv Channels Guncelleniyor   #'
echo '#############################################'
echo $LINE
echo 'DESTEK ICIN **arslan_plaza@outlook.com** IRTIBATA GECINIZ'
echo 'LUTFEN BEKLEYIN KANALLAR YUKLENIYOR'
sleep 2
wget http://remyteam.xp3.biz/Remy_IpTv/userbouquet.Remy_IPTV1.tv -qO /etc/enigma2/userbouquet.Remy_IPTV1.tv
wget http://remyteam.xp3.biz/Remy_IpTv/userbouquet.Remy_IPTV2.tv -qO /etc/enigma2/userbouquet.Remy_IPTV2.tv
wget http://remyteam.xp3.biz/Remy_IpTv/userbouquet.Remy_IPTV3.tv -qO /etc/enigma2/userbouquet.Remy_IPTV3.tv
wget http://remyteam.xp3.biz/Remy_IpTv/userbouquet.Remy_IPTV4.tv -qO /etc/enigma2/userbouquet.Remy_IPTV4.tv
echo ""
echo "    ***  R E M Y  IPTV GUNCELLENDI ***"
echo ""
echo "    ***  UYDU ALICINIZI YENIDEN BASLATILIYOR ***"
echo ""
sleep 1
killall -9 enigma2
exit 0