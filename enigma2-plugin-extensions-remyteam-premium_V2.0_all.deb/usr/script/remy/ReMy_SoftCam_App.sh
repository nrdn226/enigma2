#!/bin/sh
wget http://remyteam.xp3.biz/remy-cammanager_V1.1_all.ipk -qO /tmp/remy-cammanager_V1.1_all.ipk
echo ""
echo "    ***  REMY SoftCamApp KURULDU EKLENTILERDEN CAM SECINIZ ***"
echo ""
echo "    ***  DESTEK ICIN  arslan_plaza@outlook.com ***"
echo ""
echo "    ***  UYDU ALICINIZI YENIDEN BASLATILIYOR ***"
echo ""
sleep 2
rm -rf /usr/camscript > /dev/null
echo 'DELETED FILES FROM camscript FOLDER'
opkg --force-overwrite install /tmp/remy-cammanager_V1.1_all.ipk
opkg update && opkg install --force-reinstall /tmp/remy-cammanager_V1.1_all.ipk
opkg install --force-reinstall /tmp/*.ipk
sleep 1
rm -rf /tmp/remy-cammanager_V1.1_all.ipk > /dev/null
echo "    ***  REMY SoftCamApp KURULDU EKLENTILERDEN CAM SECINIZ ***"
sleep 1
killall -9 enigma2
exit 0