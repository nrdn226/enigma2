#!/bin/sh
wget http://remyteam.xp3.biz/dreambox/oscam.constant.cw -qO /etc/tuxbox/config/oscam.constant.cw
wget http://remyteam.xp3.biz/dreambox/oscam.keys -qO /etc/tuxbox/config/oscam.keys
wget http://remyteam.xp3.biz/dreambox/SoftCam.Key -qO /etc/tuxbox/config/SoftCam.Key
wget http://remyteam.xp3.biz/dreambox/biss -qO /usr/keys/biss
wget http://remyteam.xp3.biz/dreambox/biss.cfg -qO /usr/keys/biss.cfg
wget http://remyteam.xp3.biz/dreambox/camd3.keys -qO /usr/keys/camd3.keys
wget http://remyteam.xp3.biz/dreambox/constant.cw -qO /usr/keys/constant.cw
wget http://remyteam.xp3.biz/dreambox/constcw -qO /usr/keys/constcw
wget http://remyteam.xp3.biz/dreambox/constcw_older -qO /usr/keys/constcw_older
wget http://remyteam.xp3.biz/dreambox/cryptoworks -qO /usr/keys/cryptoworks
wget http://remyteam.xp3.biz/dreambox/irdeto -qO /usr/keys/irdeto
wget http://remyteam.xp3.biz/dreambox/nagra -qO /usr/keys/nagra
wget http://remyteam.xp3.biz/dreambox/replace.list -qO /usr/keys/replace.list
wget http://remyteam.xp3.biz/dreambox/via -qO /usr/keys/via
wget http://remyteam.xp3.biz/dreambox/AutoRoll.Key -qO /usr/keys/AutoRoll.Key
sleep 1
echo ""
echo "    ***  REMY TUM KEYLER GUNCELLENDI ***"
echo ""
echo "    ***  DESTEK ICIN arslan_plaza@outlook.com IRTIBATA GECINIZ ***"
echo ""
echo "    ***  UYDU ALICINIZ YENIDEN BASLATILIYOR ***"
echo ""
sleep 2
killall -9 enigma2
exit 0