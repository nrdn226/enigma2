#!/bin/sh
wget http://remyteam.xp3.biz/bootvideo-remy-matrix_1.0_all.ipk -qO /tmp/bootvideo-remy-matrix_1.0_all.ipk
opkg --force-overwrite install /tmp/bootvideo-remy-matrix_1.0_all.ipk
opkg update && opkg install --force-reinstall /tmp/bootvideo-remy-matrix_1.0_all.ipk
sleep 2
rm -rf /tmp/bootvideo-remy-matrix_1.0_all.ipk > /dev/null
echo '***REMY MATRIX BOOT VIDEO YUKLENMISTIR***'
sleep 1
reboot
exit 0
