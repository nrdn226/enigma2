#!/bin/sh
cd /tmp
rm -f /tmp/news.txt
wget http://remyteam.xp3.biz/news.txt -qO /tmp/news.txt > /dev/null 2>&1

if [ -f /tmp/news.txt ]; then 
		cat /tmp/news.txt
		echo
else
		echo
		echo "Suan için Herhangi Bir Haber Mevcut Degildir, Tesekkurler"
		echo
fi

exit 0 
