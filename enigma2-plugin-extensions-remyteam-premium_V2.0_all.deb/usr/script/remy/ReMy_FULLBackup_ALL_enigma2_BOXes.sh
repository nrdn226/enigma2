#!/bin/sh
echo '#############################################'
echo '#     ReMy TeaM REMY MATRIX MOD BACKUP      #'
echo '#############################################'
echo $LINE
echo 'ReMy TeaM REMY MATRIX MOD BACKUP'
echo 'LUTFEN BEKLEYIN BACKUP HAZIRLANIYOR'
sleep 2
wget http://remyteam.xp3.biz/enigma2-plugin-extensions-remyfullbackup_V2.0_all.ipk -qO /tmp/enigma2-plugin-extensions-remyfullbackup_V2.0_all.ipk > /dev/null
opkg --force-overwrite install /tmp/enigma2-plugin-extensions-remyfullbackup_V2.0_all.ipk
opkg install --force-reinstall --force-depends /tmp/enigma2-plugin-extensions-remyfullbackup_V2.0_all.ipk
opkg install --force-reinstall /tmp/*.ipk
rm -rf /tmp/enigma2-plugin-extensions-remyfullbackup_V2.0_all.ipk > /dev/null
opkg install --force-reinstall /tmp/*.ipk
opkg --force-overwrite install /tmp/*.ipk
opkg update && opkg install --force-reinstall --force-depends /tmp/*.ipk
echo 'BACKUP KURULUMU TAMAMLANDI CIHAZ YENIDEN BASLATILIYOR'
sleep 1
killall -9 enigma2
exit 0