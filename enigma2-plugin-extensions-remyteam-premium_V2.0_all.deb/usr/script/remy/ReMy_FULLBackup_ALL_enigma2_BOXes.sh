#!/bin/sh
echo '#############################################'
echo '#          REMY MATRIX MOD BACKUP           #'
echo '#############################################'
echo $LINE
echo 'REMY MATRIX MOD BACKUP'
echo 'LUTFEN BEKLEYIN BACKUP HAZIRLANIYOR'
sleep 2
wget http://remyteam.xp3.biz/remyfullbackup_V1.0_all.ipk -qO /tmp/remyfullbackup_V1.0_all.ipk > /dev/null
opkg --force-overwrite install /tmp/*.ipk
opkg --force-overwrite install /tmp/remyfullbackup_V1.0_all.ipk
opkg install --force-reinstall --force-depends /tmp/remyfullbackup_V1.0_all.ipk
rm -rf /tmp/remyfullbackup_V1.0_all.ipk > /dev/null
opkg --force-overwrite install /tmp/enigma2-plugin-extensions-mediaportal_7.7.1.1_all.ipk
opkg --force-overwrite install /tmp/enigma2-plugin-extensions-subssupport_1.5.4_20150824_all.ipk
opkg --force-overwrite install /tmp/enigma2-plugin-extensions-mediaplayer2_0.61_20150909_all.ipk
echo 'BACKUP KURULUMU TAMAMLANDI CIHAZ YENIDEN BASLATILIYOR'
sleep 2
killall -9 enigma2
exit 0