#!/bin/sh
opkg update && opkg install --force-reinstall  --force-depends enigma2-plugin-extensions-hbbtv
sleep 1
wget http://remyteam.xp3.biz/youtubetv-remy_V1.0_all.ipk -qO /tmp/youtubetv-remy_V1.0_all.ipk
opkg --force-overwrite install /tmp/youtubetv-remy_V1.0_all.ipk
opkg update && opkg install --force-reinstall  --force-depends /tmp/youtubetv-remy_V1.0_all.ipk
opkg install --force-reinstall /tmp/*.ipk
sleep 1
echo ""
echo "    ***  HBBTV  YOUTUBE_TV VE OPERA WEB BROWSER KURULDU ***"
sleep 1
reboot
exit 0