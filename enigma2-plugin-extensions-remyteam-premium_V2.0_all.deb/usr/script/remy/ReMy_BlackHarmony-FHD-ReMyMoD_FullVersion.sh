#!/bin/sh
opkg update && opkg install curl
curl https://github.com/remytr/enigma2/raw/master/enigma2-plugin-skins-blackharmony-fhd-by-remymod_V4.4_mipsel.ipk -Lko /tmp/enigma2-plugin-skins-blackharmony-fhd-by-remymod_V4.4_mipsel.ipk
echo ""
echo "    ***  REMY_TEAM PLUGINI INDIRILIYOR ***"
echo ""
echo "    ***  DESTEK ICIN arslan_plaza@outlook.com IRTIBATA GECINIZ ***"
echo ""
sleep 1
opkg --force-overwrite install /tmp/enigma2-plugin-skins-blackharmony-fhd-by-remymod_V4.4_mipsel.ipk
opkg install --force-reinstall /tmp/*.ipk
opkg update && opkg install --force-reinstall /tmp/enigma2-plugin-skins-blackharmony-fhd-by-remymod_V4.4_mipsel.ipk
sleep 1
echo 'DESTEK ICIN arslan_plaza@outlook.com'
echo  '***  REMY_TEAM V2.0 ***'
killall -9 enigma2
exit 0