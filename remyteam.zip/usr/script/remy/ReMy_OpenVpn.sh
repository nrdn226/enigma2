# BY Remy 
# ENIGMA2 /usr/script
#!/bin/sh
curl https://github.com/remytr/enigma2/raw/master/remy-openvpn_V1.1_all.ipk -Lko /tmp/remy-openvpn_V1.1_all.ipk
echo ""
echo "    ***  http://www.vpnbook.com/freevpn ***"
echo ""
echo "    ***  ADRESINDE ALTTAKI Password YAZAN SiFREYi ALIN ***"
echo ""
echo "    ***  ETC/OPENVPN/login.txt dosyasina alt satira yapistiriniz. ***"
echo ""
echo "    ***  iSLEM DEVAM EDiYOR BEKLEYiN LUTFEN ***"
echo ""
sleep 5
opkg install openvpn
rm -rf /etc/openvpn > /dev/null
echo 'DELETED FILES FROM camscript FOLDER'
opkg install --force-reinstall /tmp/remy-openvpn_V1.1_all.ipk
sleep 1
rm -rf /tmp/remy-openvpn_V1.1_all.ipk > /dev/null
echo 'DELETED FILES FROM TMP FOLDER'
init 4
init 3
sleep 2
exit 0