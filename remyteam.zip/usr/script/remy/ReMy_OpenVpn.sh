#!/bin/sh
wget http://remyteam.xp3.biz/remy-openvpn_V1.1_all.ipk -qO /tmp/remy-openvpn_V1.1_all.ipk
echo ""
echo "    ***  http://www.vpnbook.com/freevpn ***"
echo ""
echo "    ***  ADRESINDE ALTTAKI Password YAZAN SiFREYi ALIN ***"
echo ""
echo "    ***  ETC/OPENVPN/login.txt dosyasina alt satira yapistiriniz. ***"
echo ""
echo "    ***  iSLEM DEVAM EDiYOR BEKLEYiN LUTFEN ***"
echo ""
sleep 3
opkg install openvpn
rm -rf /etc/openvpn > /dev/null
echo 'DELETED FILES FROM camscript FOLDER'
opkg --force-overwrite install /tmp/remy-openvpn_V1.1_all.ipk
opkg install --force-reinstall /tmp/remy-openvpn_V1.1_all.ipk
sleep 1
rm -rf /tmp/remy-openvpn_V1.1_all.ipk > /dev/null
echo 'DELETED FILES FROM TMP FOLDER'
sleep 2
init 4
init 3
exit 0