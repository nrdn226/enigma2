# BY Remy 
# ENIGMA2 /usr/script
#!/bin/sh
echo '#############################################'
echo '# ReMy TeaM SATELLITE_IPTV Channel Settigns #'
echo '#############################################'
echo $LINE
echo 'INDIRILIYOR LUTFEN BEKLEYIN'
curl https://github.com/remytr/enigma2/raw/master/remyteam-16channel-settings_V1.0_all.ipk -Lko /tmp/remyteam-16channel-settings_V1.0_all.ipk
echo 'DOWNLOAD TAMAMLANMISTIR'
opkg --force-overwrite install /tmp/remyteam-16channel-settings_V1.0_all.ipk
opkg install --force-reinstall --force-depends /tmp/remyteam-16channel-settings_V1.0_all.ipk
sleep 1
echo 'RELOADING SERVICES - PLEASE WAIT'
wget -qO - http://127.0.0.1/web/servicelistreload?mode=1 > /dev/null
wget -qO - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null
echo 'REMY TEAM KULLANDIGINIZ ICIN TESEKKURLER'
reboot
exit 0

