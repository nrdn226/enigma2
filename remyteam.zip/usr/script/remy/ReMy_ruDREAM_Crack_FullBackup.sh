#!/bin/sh
wget http://remyteam.xp3.biz/remy-rudream-crackbackup_V1.1_all.ipk -qO /tmp/remy-rudream-crackbackup_V1.1_all.ipk
echo ""
echo "    ***  REMY FULL BACKUP YUKLENIYOR ***"
echo ""
echo "    ***  DESTEK ICIN IRTIBATA GECINIZ ***"
echo ""
echo "    ***  UYDU ALICINIZI YENIDEN BASLATILIYOR ***"
echo ""
opkg --force-overwrite install /tmp/remy-rudream-crackbackup_V1.1_all.ipk
opkg install --force-reinstall /tmp/remy-rudream-crackbackup_V1.1_all.ipk
sleep 1
rm -rf /tmp/remy-rudream-crackbackup_V1.1_all.ipk > /dev/null
sleep 2
init 4
init 3
exit 0