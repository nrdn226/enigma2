#!/bin/sh
echo '#############################################'
echo '#     ReMy TeaM REMY MATRIX MOD BACKUP      #'
echo '#############################################'
echo $LINE
echo 'ReMy TeaM REMY MATRIX MOD BACKUP'
echo 'LUTFEN BEKLEYIN BACKUP HAZIRLANIYOR'
sleep 2
wget http://remyteam.xp3.biz/remyfullbackup_V1.0_all.ipk -qO /tmp/remyfullbackup_V1.0_all.ipk > /dev/null
opkg --force-overwrite install /tmp/remyfullbackup_V1.0_all.ipk
opkg install --force-reinstall --force-depends /tmp/remyfullbackup_V1.0_all.ipk
rm -rf /tmp/remyfullbackup_V1.0_all.ipk > /dev/null
opkg --force-overwrite install /tmp/*.ipk
opkg install --force-reinstall --force-depends /tmp/*.ipk
echo 'BACKUP KURULUMU TAMAMLANDI CIHAZ YENIDEN BASLATILIYOR'
sleep 2
init 4
init 3
exit 0