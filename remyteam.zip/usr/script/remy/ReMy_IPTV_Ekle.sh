# BY Remy 
# ENIGMA2 /usr/script
#!/bin/sh
echo '#############################################'
echo '#    ReMy TeaM IpTv Channels Yuklenıyor     #'
echo '#############################################'
echo $LINE
echo 'LUTFEN BEKLEYIN KANALLAR YUKLENIYOR'
sleep 2
wget -O /etc/enigma2/userbouquet."$bouquet"Remy_IPTV4.tv $url;if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet > /dev/null;then echo "[+]Creating Folder for iptv and rehashing...";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.'$bouquet'Remy_IPTV4.tv" ORDER BY bouquet' >> /etc/enigma2/new_bouquets.tv; cat /etc/enigma2/bouquets.tv | sed -n '2,$p' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;rm /usr/bin/enigma2_pre_start.sh;echo "writing to the file.. NO NEED FOR REBOOT";echo "/bin/sh "$directory" > /dev/null 2>&1 &" > /usr/bin/enigma2_pre_start.sh;chmod 777 /usr/bin/enigma2_pre_start.sh;wget -Lko - "<a href="http://127.0.0.1/web/servicelistreload?mode=2";wget">http://127.0.0.1/web/servicelistreload?mode=2";wget</a> -Lko - "<a href="http://127.0.0.1/web/servicelistreload?mode=2";">http://127.0.0.1/web/servicelistreload?mode=2";</a> curl https://github.com/remytr/enigma2/raw/master/userbouquet.Remy_IPTV4.tv
wget -O /etc/enigma2/userbouquet."$bouquet"Remy_IPTV3.tv $url;if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet > /dev/null;then echo "[+]Creating Folder for iptv and rehashing...";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.'$bouquet'Remy_IPTV3.tv" ORDER BY bouquet' >> /etc/enigma2/new_bouquets.tv; cat /etc/enigma2/bouquets.tv | sed -n '2,$p' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;rm /usr/bin/enigma2_pre_start.sh;echo "writing to the file.. NO NEED FOR REBOOT";echo "/bin/sh "$directory" > /dev/null 2>&1 &" > /usr/bin/enigma2_pre_start.sh;chmod 777 /usr/bin/enigma2_pre_start.sh;wget -Lko - "<a href="http://127.0.0.1/web/servicelistreload?mode=2";wget">http://127.0.0.1/web/servicelistreload?mode=2";wget</a> -Lko - "<a href="http://127.0.0.1/web/servicelistreload?mode=2";">http://127.0.0.1/web/servicelistreload?mode=2";</a> curl https://github.com/remytr/enigma2/raw/master/userbouquet.Remy_IPTV3.tv
wget -O /etc/enigma2/userbouquet."$bouquet"Remy_IPTV2.tv $url;if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet > /dev/null;then echo "[+]Creating Folder for iptv and rehashing...";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.'$bouquet'Remy_IPTV2.tv" ORDER BY bouquet' >> /etc/enigma2/new_bouquets.tv; cat /etc/enigma2/bouquets.tv | sed -n '2,$p' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;rm /usr/bin/enigma2_pre_start.sh;echo "writing to the file.. NO NEED FOR REBOOT";echo "/bin/sh "$directory" > /dev/null 2>&1 &" > /usr/bin/enigma2_pre_start.sh;chmod 777 /usr/bin/enigma2_pre_start.sh;wget -Lko - "<a href="http://127.0.0.1/web/servicelistreload?mode=2";wget">http://127.0.0.1/web/servicelistreload?mode=2";wget</a> -Lko - "<a href="http://127.0.0.1/web/servicelistreload?mode=2";">http://127.0.0.1/web/servicelistreload?mode=2";</a> curl https://github.com/remytr/enigma2/raw/master/userbouquet.Remy_IPTV2.tv
wget -O /etc/enigma2/userbouquet."$bouquet"Remy_IPTV1.tv $url;if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet > /dev/null;then echo "[+]Creating Folder for iptv and rehashing...";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.'$bouquet'Remy_IPTV1.tv" ORDER BY bouquet' >> /etc/enigma2/new_bouquets.tv; cat /etc/enigma2/bouquets.tv | sed -n '2,$p' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;rm /usr/bin/enigma2_pre_start.sh;echo "writing to the file.. NO NEED FOR REBOOT";echo "/bin/sh "$directory" > /dev/null 2>&1 &" > /usr/bin/enigma2_pre_start.sh;chmod 777 /usr/bin/enigma2_pre_start.sh;wget -Lko - "<a href="http://127.0.0.1/web/servicelistreload?mode=2";wget">http://127.0.0.1/web/servicelistreload?mode=2";wget</a> -Lko - "<a href="http://127.0.0.1/web/servicelistreload?mode=2";">http://127.0.0.1/web/servicelistreload?mode=2";</a> curl https://github.com/remytr/enigma2/raw/master/userbouquet.Remy_IPTV1.tv
curl https://github.com/remytr/enigma2/raw/master/userbouquet.Remy_IPTV1.tv -Lko /etc/enigma2/userbouquet.Remy_IPTV1.tv
curl https://github.com/remytr/enigma2/raw/master/userbouquet.Remy_IPTV2.tv -Lko /etc/enigma2/userbouquet.Remy_IPTV2.tv
curl https://github.com/remytr/enigma2/raw/master/userbouquet.Remy_IPTV3.tv -Lko /etc/enigma2/userbouquet.Remy_IPTV3.tv
curl https://github.com/remytr/enigma2/raw/master/userbouquet.Remy_IPTV4.tv -Lko /etc/enigma2/userbouquet.Remy_IPTV4.tv
echo ""
echo "    ***  REMY IPTV LISTEYE EKLENDI  ***"
echo ""
echo "    ***  DESTEK ICIN arslan_plaza@outlook.com IRTIBATA GECINIZ ***"
echo ""
echo "    ***  UYDU ALICINIZI YENIDEN BASLATILIYOR ***"
echo ""
init 4
init 3
sleep 1
exit 0