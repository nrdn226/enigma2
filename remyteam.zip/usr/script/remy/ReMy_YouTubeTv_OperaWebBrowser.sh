# BY Remy 
# ENIGMA2 /usr/script
#!/bin/sh
opkg update && opkg install --force-reinstall  --force-depends enigma2-plugin-extensions-hbbtv
sleep 1
curl https://github.com/remytr/enigma2/raw/master/youtubetv-remy_V1.0_all.ipk -Lko /tmp/youtubetv-remy_V1.0_all.ipk
opkg install --force-reinstall  --force-depends /tmp/youtubetv-remy_V1.0_all.ipk
sleep 1
echo ""
echo "    ***  HBBTV  YOUTUBE_TV VE OPERA WEB BROWSER KURULDU ***"
sleep 1
reboot
exit 0