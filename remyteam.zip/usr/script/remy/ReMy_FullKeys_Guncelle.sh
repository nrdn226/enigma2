# BY Remy 
# ENIGMA2 /usr/script
#!/bin/sh
curl https://github.com/remytr/enigma2/raw/master/oscam.constant.cw -Lko /etc/tuxbox/config/oscam.constant.cw
curl https://github.com/remytr/enigma2/raw/master/oscam.keys -Lko /etc/tuxbox/config/oscam.keys
curl https://github.com/remytr/enigma2/raw/master/SoftCam.Key -Lko /etc/tuxbox/config/SoftCam.Key
curl https://github.com/remytr/enigma2/raw/master/biss -Lko /usr/keys/biss
curl https://github.com/remytr/enigma2/raw/master/biss.cfg -Lko /usr/keys/biss.cfg
curl https://github.com/remytr/enigma2/raw/master/camd3.keys -Lko /usr/keys/camd3.keys
curl https://github.com/remytr/enigma2/raw/master/constant.cw -Lko /usr/keys/constant.cw
curl https://github.com/remytr/enigma2/raw/master/constcw -Lko /usr/keys/constcw
curl https://github.com/remytr/enigma2/raw/master/constcw_older -Lko /usr/keys/constcw_older
curl https://github.com/remytr/enigma2/raw/master/cryptoworks -Lko /usr/keys/cryptoworks
curl https://github.com/remytr/enigma2/raw/master/irdeto -Lko /usr/keys/irdeto
curl https://github.com/remytr/enigma2/raw/master/nagra -Lko /usr/keys/nagra
curl https://github.com/remytr/enigma2/raw/master/replace.list -Lko /usr/keys/replace.list
curl https://github.com/remytr/enigma2/raw/master/SoftCam.Key -Lko /usr/keys/SoftCam.Key
curl https://github.com/remytr/enigma2/raw/master/via -Lko /usr/keys/via
curl https://github.com/remytr/enigma2/raw/master/AutoRoll.Key -Lko /usr/keys/AutoRoll.Key
echo ""
echo "    ***  REMY TUM KEYLER GUNCELLENDI ***"
echo ""
echo "    ***  DESTEK ICIN arslan_plaza@outlook.com IRTIBATA GECINIZ ***"
echo ""
echo "    ***  UYDU ALICINIZ YENIDEN BASLATILIYOR ***"
echo ""
init 4
init 3
sleep 1
exit 0