#!/bin/sh

cd /tmp
rm -f /tmp/Plugin_Kullanma_Kilavuzu.txt
wget http://remyteam.xp3.biz/Plugin_Kullanma_Kilavuzu.txt > /dev/null 2>&1

if [ -f /tmp/Plugin_Kullanma_Kilavuzu.txt ]; then 
		cat /tmp/Plugin_Kullanma_Kilavuzu.txt
		echo
else
		echo
		echo "Suan icin Herhangi Bir Haber Mevcut Degildir, Tesekkurler"
		echo
fi

exit 0 
