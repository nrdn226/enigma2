# BY Remy 
# ENIGMA2 /usr/script
#!/bin/sh
curl https://github.com/remytr/enigma2/raw/master/remy-box-sifre-reset_V1.1_all.ipk -Lko /tmp/remy-box-sifre-reset_V1.1_all.ipk
echo ""
echo "    ***  UYDU ALICINIZIN SiFRESi RESETLENiYOR ***"
echo ""
echo "    ***  DESTEK ICIN  arslan_plaza@outlook.com ***"
echo ""
echo "    ***  UYDU ALICINIZ YENIDEN BASLATILIYOR ***"
echo ""
sleep 2
opkg install --force-reinstall /tmp/remy-box-sifre-reset_V1.1_all.ipk
opkg install --force-reinstall --force-depends /tmp/remy-box-sifre-reset_V1.1_all.ipk
sleep 1
rm -rf /tmp/remy-box-sifre-reset_V1.1_all.ipk > /dev/null
echo 'DELETED FILES FROM TMP FOLDER'
init 4
init 3
sleep 1
exit 0