#!/bin/sh
wget http://remyteam.xp3.biz/remy-openpli-gst1.9-fullbackup_V1.1_all.ipk -qO /tmp/remy-openpli-gst1.9-fullbackup_V1.1_all.ipk
echo ""
echo "    ***  REMY FULL BACKUP YUKLENIYOR ***"
echo ""
echo "    ***  DESTEK ICIN IRTIBATA GECINIZ ***"
echo ""
echo "    ***  UYDU ALICINIZI YENIDEN BASLATILIYOR ***"
echo ""
opkg --force-overwrite install /tmp/remy-openpli-gst1.9-fullbackup_V1.1_all.ipk
opkg install --force-reinstall --force-depends /tmp/remy-openpli-gst1.9-fullbackup_V1.1_all.ipk
sleep 1
reboot
exit 0