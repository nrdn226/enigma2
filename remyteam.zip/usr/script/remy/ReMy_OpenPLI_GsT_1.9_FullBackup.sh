# BY Remy 
# ENIGMA2 /usr/script
#!/bin/sh
curl https://github.com/remytr/enigma2/raw/master/remy-openpli-gst1.9-fullbackup_V1.1_all.ipk -Lko /tmp/remy-openpli-gst1.9-fullbackup_V1.1_all.ipk
echo ""
echo "    ***  REMY FULL BACKUP YUKLENIYOR ***"
echo ""
echo "    ***  DESTEK ICIN IRTIBATA GECINIZ ***"
echo ""
echo "    ***  UYDU ALICINIZI YENIDEN BASLATILIYOR ***"
echo ""
opkg --force-overwrite install /tmp/remy-openpli-gst1.9-fullbackup_V1.1_all.ipk
sleep 1
reboot
exit 0