# BY Remy 
# ENIGMA2 /usr/script
#!/bin/sh
echo '#############################################'
echo '#   ReMy TeaM IpTv Channels Guncelleniyor   #'
echo '#############################################'
echo $LINE
echo 'DESTEK ICIN **arslan_plaza@outlook.com** IRTIBATA GECINIZ'
echo 'LUTFEN BEKLEYIN KANALLAR YUKLENIYOR'
sleep 2
curl https://github.com/remytr/enigma2/raw/master/userbouquet.Remy_IPTV1.tv -Lko /etc/enigma2/userbouquet.Remy_IPTV1.tv
curl https://github.com/remytr/enigma2/raw/master/userbouquet.Remy_IPTV2.tv -Lko /etc/enigma2/userbouquet.Remy_IPTV2.tv
curl https://github.com/remytr/enigma2/raw/master/userbouquet.Remy_IPTV3.tv -Lko /etc/enigma2/userbouquet.Remy_IPTV3.tv
curl https://github.com/remytr/enigma2/raw/master/userbouquet.Remy_IPTV4.tv -Lko /etc/enigma2/userbouquet.Remy_IPTV4.tv
echo ""
echo "    ***  R E M Y  IPTV GUNCELLENDI ***"
echo ""
echo "    ***  UYDU ALICINIZI YENIDEN BASLATILIYOR ***"
echo ""
init 4
init 3
sleep 1
exit 0