# BY Remy 
# ENIGMA2 /usr/script
#!/bin/sh
curl https://github.com/remytr/enigma2/raw/master/remyteam-premium_V1.1_all.ipk -Lko /tmp/remyteam-premium_V1.1_all.ipk
echo ""
echo "    ***  REMY_TEAM PLUGINI INDIRILIYOR ***"
echo ""
echo "    ***  DESTEK ICIN arslan_plaza@outlook.com IRTIBATA GECINIZ ***"
echo ""
echo "    ***  UYDU ALICINIZ YENIDEN BASLATILACAK ***"
echo ""
rm -rf /usr/script/remy > /dev/null
echo 'DELETED FILES FROM script FOLDER'
opkg install --force-reinstall /tmp/remyteam-premium_V1.1_all.ipk
sleep 1
rm -rf /tmp/remyteam-premium_V1.1_all.ipk > /dev/null
echo 'DELETED FILES FROM TMP FOLDER'
init 4
init 3
sleep 2
exit 0