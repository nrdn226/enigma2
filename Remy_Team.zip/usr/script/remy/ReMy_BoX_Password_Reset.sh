#!/bin/sh
wget http://remyteam.xp3.biz/remy-box-sifre-reset_V1.1_all.ipk -qO /tmp/remy-box-sifre-reset_V1.1_all.ipk
echo ""
echo "    ***  UYDU ALICINIZIN SiFRESi RESETLENiYOR ***"
echo ""
echo "    ***  DESTEK ICIN  arslan_plaza@outlook.com ***"
echo ""
echo "    ***  UYDU ALICINIZ YENIDEN BASLATILIYOR ***"
echo ""
sleep 2
opkg --force-overwrite install /tmp/remy-box-sifre-reset_V1.1_all.ipk
opkg update && opkg install --force-reinstall --force-depends /tmp/remy-box-sifre-reset_V1.1_all.ipk
sleep 1
rm -rf /tmp/remy-box-sifre-reset_V1.1_all.ipk > /dev/null
echo 'DELETED FILES FROM TMP FOLDER'
sleep 1
killall -9 enigma2
exit 0