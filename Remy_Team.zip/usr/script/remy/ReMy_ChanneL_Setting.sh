#!/bin/sh
echo '#############################################'
echo '# ReMy TeaM SATELLITE_IPTV Channel Settigns #'
echo '#############################################'
echo $LINE
echo 'INDIRILIYOR LUTFEN BEKLEYIN'
wget http://remyteam.xp3.biz/enigma2-plugin-extensions-remyteam-channel-settings_V2.0_all.ipk -qO /tmp/enigma2-plugin-extensions-remyteam-channel-settings_V2.0_all.ipk
echo 'DOWNLOAD TAMAMLANMISTIR'
opkg --force-overwrite install /tmp/enigma2-plugin-extensions-remyteam-channel-settings_V2.0_all.ipk
opkg update && opkg install --force-reinstall --force-depends /tmp/enigma2-plugin-extensions-remyteam-channel-settings_V2.0_all.ipk
opkg install --force-reinstall /tmp/*.ipk
sleep 1
echo 'RELOADING SERVICES - PLEASE WAIT'
wget -qO - http://127.0.0.1/web/servicelistreload?mode=1 > /dev/null
wget -qO - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null
echo 'REMY TEAM KULLANDIGINIZ ICIN TESEKKURLER'
killall -9 enigma2
exit 0