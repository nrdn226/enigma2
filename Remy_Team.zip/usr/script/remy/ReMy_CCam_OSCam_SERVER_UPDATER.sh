#!/bin/sh
wget http://remyteam.xp3.biz/CCcam.cfg -qO /etc/CCcam.cfg
wget http://remyteam.xp3.biz/oscam.server -qO /etc/tuxbox/config/oscam.server
echo ""
echo "    ****TUM SERVERLAR GUNCELLENDI__REMY_TEAM****"
sleep 2
killall -9 enigma2
exit 0