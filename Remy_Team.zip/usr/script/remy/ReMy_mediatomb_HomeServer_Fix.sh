#!/bin/sh
opkg update && opkg install --force-reinstall  --force-depends enigma2-plugin-extensions-mediatomb
wget http://remyteam.xp3.biz/remy-mediatomb-fix_V1.1_all.ipk -qO /tmp/remy-mediatomb-fix_V1.1_all.ipk
opkg --force-overwrite install /tmp/remy-mediatomb-fix_V1.1_all.ipk
opkg update && opkg install --force-reinstall  --force-depends /tmp/remy-mediatomb-fix_V1.1_all.ipk
opkg install --force-reinstall /tmp/*.ipk
sleep 1
echo ""
echo "               ***  MEDIATOMB_HOME_SERVER_KURULDU ***"
echo ""
echo " ***PC DEN KANALLARINIZI VEYA FILMLERINIZI SERVERINIZA EKLEYINIZ ***"
sleep 1
reboot
exit 0
