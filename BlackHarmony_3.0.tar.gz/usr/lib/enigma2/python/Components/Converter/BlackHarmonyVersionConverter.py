from Components.Converter.Converter import Converter
from Components.Element import cached
from Tools.Directories import SCOPE_CURRENT_SKIN, resolveFilename
import urllib2
from contextlib import closing

from os.path import exists, getmtime
from time import time

class BlackHarmonyVersionConverter(Converter, object):
#class BlackHarmonyVersionConverter(object):
    DOWNLOAD_INTERVAL_IN_SEC = 86400 #every day
    REMOTE_FILE_URL = "http://blackharmony.pl/blackharmony_version"
    REMOTE_FILE_NAME = resolveFilename(SCOPE_CURRENT_SKIN) + "blackharmony_online_version"

    def __init__(self, arg):
        Converter.__init__(self, arg)
#        a=1

    @cached
    def getBoolean(self):
        localVersionFile = resolveFilename(SCOPE_CURRENT_SKIN) + "blackharmony_version"
#        localVersionFile = "/tmp/blackharmony_version_old"
        if not exists(localVersionFile):
            return False

        remoteVersionFile = self.REMOTE_FILE_NAME
        if not exists(remoteVersionFile):
            self.downloadFile(self.REMOTE_FILE_URL, remoteVersionFile)

        if exists(remoteVersionFile):
            lastDownloadTime = getmtime(remoteVersionFile)
            currentTime = time()
            print str(lastDownloadTime)+" - "+str(currentTime)+" = "+str(currentTime-lastDownloadTime)
            if (currentTime-lastDownloadTime)>self.DOWNLOAD_INTERVAL_IN_SEC:
                self.downloadFile(self.REMOTE_FILE_URL, remoteVersionFile)

        #we have both files
            localVersion = self.readVersion(localVersionFile)
            remoteVersion = self.readVersion(remoteVersionFile)
            print "Local v: "+str(localVersion)+" -> Remote v: "+str(remoteVersion)

            if (localVersion<remoteVersion):
                return True

        return False

    boolean = property(getBoolean)

    def readVersion(self, fileName):
        file = open(fileName, "r")
        strVersion = file.readline()
        try: # j00zek 03/10/15 fix GS when no inet connection
            version = float(strVersion.strip())
        except:
            version = 9999 #results in setting False
        file.close()
        return version

    def downloadFile(self, url, fileName):
#        print "URL: "+url
#        print "File: "+fileName
#        print "localFile: "+str(localFile)
        try:
            remoteFile = urllib2.urlopen(url)
            localFile = open(fileName, 'w')
            localFile.write(remoteFile.read())
        except:
            print "error downloading %s file" % url

    def changed(self, what):
        Converter.changed(self, what)

#x = BlackHarmonyVersionConverter("test")
#x.downloadFile(x.REMOTE_FILE_URL, BlackHarmonyVersionConverter.REMOTE_FILE_NAME)
#print "bool= "+str(x.getBoolean())